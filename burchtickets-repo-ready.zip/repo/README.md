# BurchTickets — Full Stack

This connects the frontend site to a real Node.js/Express + PostgreSQL backend,
with M-Pesa STK Push checkout and async confirmation emails.

## What's here

```
burchtickets/
  backend/
    src/
      config/db.js              PostgreSQL pool
      migrations/001_init.sql   full schema + confirm_booking() function
      middleware/auth.js        requireAuth (company), requireBuyerAuth, optionalBuyerAuth
      middleware/webhook.js     HMAC webhook verification (optional, generic)
      services/mpesaService.js  Daraja STK Push integration
      services/pesapalService.js  Pesapal (card / mobile money) integration
      services/eventAggregator.js Merges own events with external discovery sources
      services/emailQueue.js    BullMQ confirmation email worker (attaches PDF tickets)
      services/ticketPdf.js     Generates the premium PDF ticket (pdfkit + qrcode)
      controllers/               auth, buyerAuth, buyer, events, checkout, payments
                                  webhook, dashboard, tickets, discover
      routes/                    Express routers per resource
      app.js / server.js         Express app + entrypoint
    package.json
    .env.example
  frontend/
    index.html                  Buyer portal + seller (organizer) portal, one file,
                                 wired to the backend via fetch()
    images/                     Sample event flyers used by the homepage showcase
```

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# fill in DATABASE_URL, JWT_SECRET, MPESA_* keys, SMTP_* creds
npm run migrate   # creates all tables + the confirm_booking() function
npm run dev       # starts on http://localhost:4000
```

Requirements: PostgreSQL running locally or hosted (Neon, Supabase, RDS...), and
Redis if you want the async confirmation-email worker to run (comment out
`startEmailWorker()` in `server.js` if you don't have Redis yet — checkout and
payments still work without it).

## 2. Frontend setup

`frontend/index.html` talks to the backend at `http://localhost:4000/api` by
default. Open it directly in a browser, or serve it with any static server. To
point it at a different backend URL (e.g. once deployed), set this before the
script runs:

```html
<script>window.BURCHTICKETS_API_BASE = "https://api.yourdomain.com/api";</script>
```

## Paying with Pesapal (card / mobile money, alongside M-Pesa STK Push)

Buyers now see two payment options at checkout: **M-Pesa** (unchanged — STK
Push straight to their phone) and **Card / Mobile Money**, which hands off to
Pesapal's own hosted payment page (cards, M-Pesa, Airtel Money, etc. all live
there). Setup:

1. Get sandbox keys at https://developer.pesapal.com, or live keys from your
   Pesapal merchant dashboard. Set in `.env`:
   ```
   PESAPAL_ENV=sandbox            # or "live"
   PESAPAL_CONSUMER_KEY=...
   PESAPAL_CONSUMER_SECRET=...
   PESAPAL_IPN_URL=https://<your-backend-domain>/api/payments/webhook/pesapal
   PESAPAL_CALLBACK_URL=https://<your-frontend-domain>/?pesapal-return=1
   ```
2. Register the IPN URL once (whenever the backend domain or sandbox/live
   keys change):
   ```bash
   cd backend
   node src/scripts/registerPesapalIpn.js
   ```
   It prints an `ipn_id` — paste it into `.env` as `PESAPAL_IPN_ID`, then
   restart the server.
3. That's it. `POST /api/checkout` now accepts `paymentMethod: "pesapal"`
   (the frontend sends this automatically when a buyer picks that option),
   returns a `redirect_url`, and the frontend sends the buyer's browser
   there. Pesapal calls `PESAPAL_IPN_URL` server-to-server when payment
   completes — same `confirm_booking()` path as M-Pesa — and separately
   redirects the buyer's browser back to `PESAPAL_CALLBACK_URL`, where the
   frontend shows a "confirming payment" screen and polls order status
   until the ticket is ready.

Sandbox card numbers and test mobile money flows are in Pesapal's docs; no
business verification is required for sandbox testing, only for live keys.

## Why you're seeing "Load failed" on the live site

If you've deployed `frontend/index.html` as a static file (e.g. to
unduguhalisinetwork.com) and it shows a red "Load failed" banner with an
empty "Published events" section, that's expected right now — **the
frontend is static, but there's no backend running anywhere for it to talk
to yet.** `window.BURCHTICKETS_API_BASE` still points at
`http://localhost:4000/api`, which only exists on your own machine while
`npm run dev` is running there. A phone loading your live domain can't
reach your laptop — and "Load failed" is literally the raw error Safari's
`fetch()` throws when a request goes nowhere (Chrome says "Failed to fetch",
Firefox says "NetworkError..." — same underlying problem, different browser
wording). The app now shows a plain-English message here instead of that
raw text, but the underlying cause — no live backend — still needs fixing
before anyone can actually buy a ticket.

### Fastest path to a working payment flow (roughly 20–30 minutes)

Using [Render](https://render.com) + [Neon](https://neon.tech) as an
example — Railway/Fly.io + Supabase work the same way if you prefer those:

1. **Database** — create a free Neon Postgres project. Copy the connection
   string it gives you (starts with `postgres://...`).
2. **Backend** — push this `backend/` folder to a GitHub repo, then on
   Render: New → Web Service → connect that repo → Root Directory
   `backend` → Build Command `npm install` → Start Command `npm start`.
   Add these environment variables in Render's dashboard (from
   `.env.example`): `DATABASE_URL` (from step 1), `PGSSL=true`,
   `JWT_SECRET` (any long random string), `MPESA_*` (from Safaricom's
   Daraja portal — sandbox keys are free and fine for testing),
   `MPESA_CALLBACK_URL` = `https://<your-render-url>/api/payments/webhook/mpesa`.
   Leave `REDIS_HOST`/`REDIS_URL` blank for now — not required.
3. Once it's deployed, run the migration once: Render gives you a Shell tab
   on the service — run `npm run migrate` there (or run it locally with
   `DATABASE_URL` pointed at Neon).
4. **Frontend** — in `frontend/index.html`, find `window.BURCHTICKETS_API_BASE`
   and set it to `https://<your-render-url>/api`, then re-upload
   `index.html` (and the `images/` folder) to wherever you're hosting the
   static site.
5. On the backend, set `FRONTEND_ORIGIN` to your static site's real domain
   (e.g. `https://unduguhalisinetwork.com`) instead of the default `*`.
6. Test it: register a company on the live site, create an event, add a
   ticket tier, publish it, then buy a ticket with a real Safaricom test
   number from Daraja's sandbox. If the STK push arrives on your phone,
   payment acceptance is genuinely working end-to-end.

Safaricom's **production** Daraja credentials (as opposed to sandbox) need
a short business verification with Safaricom before they'll process real
M-Pesa payments — that's a Safaricom process, not something this codebase
or I can bypass.

None of this can happen inside this chat — it needs your own hosting
account, your own database, and your own Safaricom Daraja credentials
(Anthropic can't create or hold those for you, and this environment has no
network access to deploy anything on your behalf). Everything in this
codebase is written to make that deployment a checklist, not a rewrite.

## 3. The flow end-to-end

1. A company registers (`/api/auth/register`) → gets a JWT.
2. They create an event (`draft`), add ticket tiers, then publish it.
3. A buyer browses `/api/events`, opens an event, picks ticket tiers, and
   checks out (`/api/checkout`) — this creates an order, holds inventory for
   15 minutes, and fires an M-Pesa STK Push to their phone.
4. Safaricom calls `MPESA_CALLBACK_URL` (`/api/payments/webhook/mpesa`) when
   the customer completes or cancels payment. The webhook is idempotent —
   duplicate callbacks are safely ignored — and on success it calls the
   `confirm_booking()` SQL function, which atomically increments sold ticket
   counts, marks the order paid, issues one `tickets` row per unit purchased
   (each with its own unique code), and records the platform's 10% commission.
5. The buyer's browser polls `GET /api/checkout/:orderId/status` until the
   order is paid, then shows a "Download PDF" button per ticket
   (`GET /api/tickets/:code/pdf`) — generated on the fly by `ticketPdf.js`
   with a scannable QR code, the buyer's name, and event details.
6. A confirmation email is queued via BullMQ and sent asynchronously with the
   same PDF tickets attached.
7. If the buyer was logged in (see below), the order is also linked to their
   account and shows up on `GET /api/buyer/orders` — a re-visitable "My
   Tickets" page with re-downloadable PDFs. Checkout itself never requires
   an account; being logged in just links the order for later.

## Buying on the platform (buyer accounts)

Buyer accounts are deliberately separate from organizer accounts — a
different table (`buyers`), a differently-shaped JWT (`role: 'buyer'`), and
routes under `/api/buyer-auth` and `/api/buyer`, so a company token can never
be replayed against buyer routes or vice versa (`middleware/auth.js` enforces
this with `requireBuyerAuth`).

- **Checkout stays guest-friendly.** `orders.buyer_id` is nullable, and
  `optionalBuyerAuth` middleware never rejects a request — it just attaches
  `buyerId` if a valid buyer token is present, so someone can buy a ticket
  in three taps with zero signup friction.
- **"My Tickets"** (`page-mytickets` in `index.html`) lists a logged-in
  buyer's past orders with event details, order status, and a "Download PDF"
  button per issued ticket — the same `/api/tickets/:code/pdf` endpoint used
  right after checkout.
- Logging in also pre-fills name/email/phone at checkout (still editable).

## Selling on the platform

- **Commission: 10% flat**, added on top of the ticket price at checkout —
  organizers keep 100% of the price they set. This is shown on the
  registration page and in the dashboard, not buried in fine print.
- **Approval:** new companies default to `pending` (see `companies.status`).
  They can create and publish events immediately, but payouts are expected to
  wait for manual verification — the dashboard shows a clear "Verification
  pending" / "Account verified" banner sourced from `GET /api/dashboard/overview`.
  Wire up an actual admin-side verification step (see below) before this
  gates real payouts.

## "What's happening in Nairobi" — live event discovery

A floating widget (bottom-right on every page) polls `GET /api/discover?city=Nairobi`
every 60 seconds and shows a merged, deduped feed of your own published
events plus events pulled from external sources — with source badges so
it's clear where each listing came from.

**Only two external sources actually work out of the box**, because they're
the only ones with a real public, city-searchable API:

| Source | Status | Notes |
|---|---|---|
| Ticketmaster Discovery API | ✅ Works | Free API key from developer.ticketmaster.com. Kenya coverage may be thin — Ticketmaster's catalog skews US/UK/AU. |
| PredictHQ | ✅ Works | Free-tier API key. Aggregates local event signals, not always a direct ticket link. |
| Bandsintown | ⚠️ Partial | API is *artist-scoped only* — set `BANDSINTOWN_ARTISTS` to a watchlist of specific artists and it'll surface their Nairobi tour dates. There's no "everything happening" endpoint. |
| Eventbrite | ❌ Not wired | Eventbrite killed public event search in Feb 2020. The API can now only read events your own organizer account owns — nothing to aggregate from arbitrary organizers. |
| Meetup | ❌ Not wired | API access now requires a paid Meetup Pro subscription plus OAuth; there's no free key anymore. |
| Kenyabuzz, Mookh, TicketSasa | ❌ Not wired | None of these publish a developer API. |

For the three with no API, the realistic path is **manual curation**: an
admin logs in, creates the event through the normal organizer flow, and
it shows up in the feed tagged `BurchTickets` like any other listing. If
you get a data-sharing agreement with any of them later, add a new
adapter in `backend/src/services/eventAggregator.js` — the `normalize()`
function documents the shape every adapter needs to return.

All of this is optional — leave the API keys blank in `.env` and the
widget just shows your own published BurchTickets events.

## Things to do before this touches real money

- **Callback URL must be public HTTPS.** M-Pesa can't reach `localhost` — use
  ngrok for local testing, or deploy the backend first.
- **Move the JWT out of JS memory.** The frontend currently keeps the auth
  token in a plain JS variable for simplicity. For production, have
  `/api/auth/login` set an `httpOnly` cookie instead, so the token can't be
  read by any injected script.
- **Rotate `JWT_SECRET` and `MPESA_WEBHOOK_SECRET`** to long random values —
  don't ship the example ones.
- **Verify company identity before enabling live M-Pesa payouts.** The schema
  has a `companies.status` field (`pending` / `verified` / `suspended`) for
  exactly this — right now new companies default to `pending` and nothing
  blocks them from publishing events. Add an admin verification step before
  go-live if you're handling other people's money.
